﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPURepairSYS
{
    internal class DBConnect
    {

        // The first connection string is used when using your laptop/PC. Check teh host name and use the Uswername and password set when 
        // you installed Oracle.
        //public const String oraDB = "Data Source = localhost/orcl; User ID = C##User1; Password = 123456;"; 

        //When in MTU Lab use this connection string
        public const String oradb = "Data Source = studentoracle:1521/orcl; User Id = T00251603; Password = 2Knockanish!;";


    }
}
