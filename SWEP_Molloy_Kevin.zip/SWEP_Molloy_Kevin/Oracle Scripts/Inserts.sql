
//RepairTypeCodes 
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('PROC','Processor');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('GCARD','Graphics Card');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('FAN','Fan');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('CASE','Case');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('BATT','Battery');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('POWSUP','Power Supply');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('MTHBRD','MotherBoard');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('COOL','CPU Cooler');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('RAM','RAM');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('STOR','Storage Device');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('WFIFADAP','Wifi Adapter');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('SCRN','Screen');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('MULT','Multiple Issues');
INSERT INTO RepairTypeCodes (RepairTypeCode,Description)
VALUES
('OTH','Other Issue');

//Part Type Codes
INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('PROC','Processor');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('GCARD','Graphics Card');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('FAN','Fan');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('CASE','Case');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('BATT','Battery');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('POWSUP','Power Supply');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('MTHBRD','MotherBoard');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('COOL','CPU Cooler');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('RAM','RAM');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('STOR','Storage Device');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('WFIFADAP','Wifi Adapter');

INSERT INTO PartTypeCodes (PartTypeCode,Description)
VALUES
('SCRN','Screen');

//Parts A O D
INSERT INTO Parts (PartId,Description,Status,Price,Quantity,PartTypeCode)
VALUES(1,'Intel Core i9','A',624.99,12,'PROC');
INSERT INTO Parts (PartId,Description,Status,Price,Quantity,PartTypeCode)
VALUES(2,'iCUE link RX120 Fan','A',129.00,30,'FAN');
INSERT INTO Parts (PartId,Description,Status,Price,Quantity,PartTypeCode)
VALUES(3,'Nitro AMD Raedon RX 7700 XT Graphics Card','O',659.00,0,'GCARD');
INSERT INTO Parts (PartId,Description,Status,Price,Quantity,PartTypeCode)
VALUES(4,'Asus 1700 ROG Strix Z790-E Motherboard','O',714,0,'MTHBRD');
INSERT INTO Parts (PartId,Description,Status,Price,Quantity,PartTypeCode)
VALUES(5,'RMx Shift Series RM850x Power Supply','D',194.99,10,'POWSUP');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(6, 'HyperTech RAM Module X6', 179.12, 12, 'D', 'RAM');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(7, 'CoolMaster Cooling System Pro7', 11.77, 0, 'O', 'COOL');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(8, 'SpeedX RAM Module X8', 63.87, 7, 'A', 'RAM');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(9, 'VoltPower Battery Pack V9', 53.57, 29, 'D', 'BATT');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(10, 'PixelEdge Graphics Card GX10', 119.68, 38, 'A', 'GCARD');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(11, 'PrimeTech Motherboard Pro11', 29.99, 0, 'O', 'MTHBRD');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(12, 'VoltPower Battery Pack V12', 129.77, 0, 'O', 'BATT');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(13, 'PowerStream Power Supply Unit PS13', 139.26, 25, 'A', 'POWSUP');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(14, 'CoolMaster Cooling System Pro14', 33.89, 0, 'O', 'COOL');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(15, 'PixelEdge Graphics Card GX15', 123.69, 2, 'D', 'GCARD');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(16, 'CoolMaster Cooling System Pro16', 34.08, 0, 'O', 'COOL');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(17, 'SpeedX RAM Module X17', 60.69, 3, 'D', 'RAM');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(18, 'VoltPower Battery Pack V18', 34.67, 7, 'A', 'BATT');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(19, 'StorEdge Storage Drive S19', 127.02, 40, 'A', 'STOR');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(20, 'HyperTech RAM Module X20', 86.51, 0, 'O', 'RAM');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(21, 'VoltPower Battery Pack V21', 98.87, 15, 'A', 'BATT');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(22, 'VoltPower Battery Pack V22', 72.28, 35, 'A', 'BATT');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(23, 'CoreX Processor Unit PX23', 197.08, 39, 'D', 'PROC');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(24, 'PixelEdge Graphics Card GX24', 166.44, 40, 'D', 'GCARD');
INSERT INTO Parts (PartId,Description,Price,Quantity,Status,PartTypeCode)
VALUES(25, 'PixelEdge Graphics Card GX25', 197.32, 0, 'O', 'GCARD');

//Customers
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(1, 'John','Bloggs','0858427373','jbloggs@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(2, 'Mary','Mahony','0871826391','mmahony@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(3, 'Jane','Doe','0861827429','jdoe@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(4, 'Leon','Kennedy','0892738102','lkennedy@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(5, 'Peter','Parker','0862736192','pparker@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(6, 'Alice','Smith','0862426745','AliceS@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(7, 'Bat','Man','0878377621','vengence@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(8, 'Charlie','Jameson','0835472458','CharlieJ@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(9, 'Diana','Williams','0810307427','DianaW@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(10, 'Ethan','Jones','0830639639','EthanJ@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(11, 'Fiona','Miller','0830606213','FionaM@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(12, 'George','Davis','0873406900','GeorgeD@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(13, 'Hannah','Garcia','0840716537','HannahG@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(14, 'Ian','Rodriguez','0815438512','IanR@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(15, 'Jane','Martinez','0874865275','JaneM@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(16, 'Liam','Smith','0861704231','LiamS@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(17, 'Olivia','Johnson','0858088331','OliviaJ@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(18, 'Noah','Brown','0891371049','NoahB@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(19, 'Emma','Taylor','0874414882','EmmaT@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(20, 'Elijah','Anderson','0855896351','ElijahA@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(21, 'Ava','Thomas','0895076403','AvaT@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(22, 'James','Jackson','0875690718','JamesJ@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(23, 'Sophia','White','0882278388','SophiaW@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(24, 'Lucas','Harris','0840551534','LucasH@email.com');
INSERT INTO Customers (CustId,FName,SName,Phone,Email)
VALUES(25, 'Mia','Martin','0843692664','MiaM@email.com');

//Repairs L-Logged E-Estimated A-Approved C-Completed X-Cancelled
//In the case of cancelled repairs the start date would mean the date the repair was cancelled
//For all intents and purposes Approved == Started, meaning approved should have a start date but not an end date.
//Also take it that approved means that the repair has been paid for
//Completed means the customer has also collected the computer
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypecode,CustId)
VALUES(1, 'Customer has problems with usb port; USB Port cleaned','C',55.00,'11/JAN/23', '21/JAN/23','OTH',1);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypecode,CustId)
VALUES(3, 'Customer has problems with battery','A',80.00,'13/JAN/23', null,'BATT',3);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypecode,CustId)
VALUES(4, 'Customers laptop is overheating','E',40.00,null, null,'COOL',4);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypecode,CustId)
VALUES(5, 'Customer has a storage anomoly','L',null,null, null,'STOR',5);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypecode,CustId)
VALUES(2, 'Customer has problems with screen','X',75.00,'13/JAN/23', null, 'SCRN',2);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(6, 'Processor replacement required due to overheating issues', 'X', 454.21, '03/FEB/24', NULL, 'PROC', 6);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(7, 'WiFi adapter failure and replacement required', 'L', NULL, NULL, NULL, 'WFIFADAP', 7);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(8, 'Screen display malfunction, requiring full screen replacement', 'L', NULL, NULL, NULL, 'SCRN', 8);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(9, 'Storage drive failure, data recovery and replacement needed', 'E', 107.75, NULL, NULL, 'STOR', 9);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(10, 'Screen display not responding, needs replacement', 'X', 176.85, '20/JUN/23', NULL, 'SCRN', 10);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(11, 'Unspecified issue requiring diagnostic and minor repairs', 'A', 48.9, '03/MAY/23', NULL, 'OTH', 11);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(12, 'WiFi connectivity issues, WiFi adapter replacement required', 'L', NULL, NULL, NULL, 'WFIFADAP', 12);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(13, 'Faulty screen display causing color distortion', 'L', NULL, NULL, NULL, 'SCRN', 13);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(14, 'Failed storage drive, urgent replacement and data transfer required', 'X', 199.08, '14/JUL/24', NULL, 'STOR', 14);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(15, 'Battery pack replacement required due to prolonged battery drain; Battery Pack Replaced', 'C', 237.67, '28/AUG/23', '21/SEP/23', 'BATT', 15);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(16, 'Memory module replacement for performance enhancement', 'L', NULL, NULL, NULL, 'RAM', 16);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(17, 'Cooling system failure, replacement and system cooling optimization required', 'E', 71.94, NULL, NULL, 'COOL', 17);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(18, 'Multiple hardware and software issues requiring full system diagnostics; Foreign objects found inside cpu, have since been removed', 'C', 190.89, '18/NOV/23', '14/DEC/23', 'MULT', 18);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(19, 'Screen display failure, needs full panel replacement; LCD Unit replaced', 'C', 306.2, '11/JUN/24', '06/JUL/24', 'SCRN', 19);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(20, 'Overheating due to faulty cooling system, replacement required; cooling system replaced', 'C', 308.08, '19/JUN/24', '14/JUL/24', 'COOL', 20);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(21, 'Battery pack replacement due to charging issues', 'L', NULL, NULL, NULL, 'BATT', 21);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(22, 'Screen display failure, requiring new screen installation', 'X', 261.97, '08/AUG/24', NULL, 'SCRN', 22);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(23, 'Multiple component failures, requiring diagnostic and repairs', 'L', NULL, NULL, NULL, 'MULT', 23);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(24, 'Screen display issue, requiring full panel replacement', 'X', 447.61, '17/JUN/24', NULL, 'SCRN', 24);
INSERT INTO Repairs (RepairId,Description,Status,Price,StartDate,CompleteDate,RepairTypeCode,CustId)
VALUES(25, 'Power supply unit replacement required due to system instability', 'A', 88.18, '15/NOV/23', NULL, 'POWSUP', 25);
//Records for the analysis files
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(26, 'Customer reports frequent system crashes; diagnostics and fixes applied', 'C', 112.50, '10/MAR/21', '22/MAR/21', 'MULT', 1);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(27, 'USB-C port malfunction; resolved with port replacement', 'C', 64.30, '14/MAY/21', '25/MAY/21', 'OTH', 2);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(28, 'Battery not charging; replaced battery unit', 'C', 129.99, '09/NOV/21', '18/NOV/21', 'BATT', 10);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(29, 'Customer experienced repeated screen flickering; screen replaced', 'C', 214.45, '03/FEB/22', '15/FEB/22', 'SCRN', 4);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(30, 'System overheating; thermal paste reapplied and cooling unit replaced', 'C', 173.20, '07/JUN/22', '20/JUN/22', 'COOL', 7);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(31, 'Frequent WiFi disconnections; WiFi module replaced', 'C', 89.99, '16/AUG/22', '28/AUG/22', 'WFIFADAP', 12);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(35, 'High CPU temperature; processor and thermal solution replaced', 'C', 289.50, '15/JAN/24', '01/FEB/24', 'PROC', 17);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(36, 'Broken USB ports; full I/O board replaced', 'C', 154.75, '12/MAR/24', '25/MAR/24', 'OTH', 9);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(37, 'Device slow and freezing; RAM upgraded and system tuned', 'C', 199.00, '18/JUL/24', '30/JUL/24', 'RAM', 16);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(38, 'Screen display malfunction screen replacement required', 'X', 199.99, '15/SEP/21', NULL, 'SCRN', 3);
INSERT INTO Repairs (RepairId, Description, Status, Price, StartDate, CompleteDate, RepairTypeCode, CustId)
VALUES(39, 'Screen flickering issue; full screen replacement needed', 'X', 225.50, '20/FEB/22', NULL, 'SCRN', 4);

//U means the part was used, X means the repair was cancelled. The parts will still be used in the parts analysis files because wetehr the part was actually used of not, it is still domething that should be considered
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed, Status)
VALUES(3, 4 ,641.99, 2, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed, Status)
VALUES(3, 2 ,75, 1, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed, Status)
VALUES(3, 5 ,45.99, 1, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed, Status)
VALUES(3, 1 ,100, 3, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(1, 23, 45.47, 3, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(1, 18, 33.38, 3, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(1, 22, 57.62, 1, 'X');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(2, 21, 89.45, 2, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(2, 19, 18.1, 2, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(2, 7, 19.43, 2, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(3, 8, 37.7, 5, 'X');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(3, 12, 69.6, 1, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(3, 16, 65.85, 2, 'X');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(4, 25, 10.01, 3, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(4, 9, 44.98, 4, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(4, 13, 86.36, 5, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(5,20, 7.15, 4, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(5, 24, 61.96, 4, 'U');
INSERT INTO RepairItems (RepairId,PartId,Price,QuantityUsed,Status)
VALUES(5, 11, 5.43, 3, 'X');


COMMIT;
