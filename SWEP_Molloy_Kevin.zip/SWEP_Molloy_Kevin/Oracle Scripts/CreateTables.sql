DROP TABLE RepairItems;
DROP TABLE Repairs;
DROP TABLE Parts;
DROP TABLE Customers;
DROP TABLE PartTypeCodes;
DROP TABLE RepairTypeCodes;


CREATE TABLE Customers(
CustId numeric(5) NOT NULL,
FName varchar2(15) NOT NULL,
SName varchar2(15) NOT NULL,
Phone varchar2(10) NOT NULL UNIQUE,
Email varchar2(25) NOT NULL UNIQUE,
CONSTRAINT PK_CustId PRIMARY KEY (CustId)
);

CREATE TABLE PartTypeCodes(
PartTypeCode varchar2(8) NOT NULL,
Description varchar2(20) NOT NULL UNIQUE,
CONSTRAINT PK_PartTypeCode PRIMARY KEY (PartTypeCode)
);

CREATE TABLE RepairTypeCodes(
RepairTypeCode varchar2(8) NOT NULL,
Description varchar2(20) NOT NULL UNIQUE,
CONSTRAINT PK_RepairTypeCode PRIMARY KEY (RepairTypeCode)
);

CREATE TABLE Parts(
PartId numeric(5) NOT NULL,
Description varchar2(50) NOT NULL UNIQUE,
Price numeric(5,2) DEFAULT(0.00) NOT NULL,
Quantity numeric(3) NOT NULL,
Status varchar2(1) NOT NULL,
PartTypeCode varchar2(8) NOT NULL,
CONSTRAINT PK_PartId PRIMARY KEY (PartId),
CONSTRAINT FK_PartTypeCode FOREIGN KEY (PartTypeCode) REFERENCES PartTypeCodes
);

CREATE TABLE Repairs(
RepairId numeric(5) NOT NULL,
Description varchar2(200) NOT NULL UNIQUE,
Status varchar2(2)DEFAULT('L') NOT NULL,
Price numeric(6,2) DEFAULT(0.00),
StartDate varchar2(10),
CompleteDate varchar2(10),
RepairTypeCode varchar2(8) NOT NULL,
CustId numeric(5) NOT NULL,
CONSTRAINT PK_RepairId PRIMARY KEY (RepairId),
CONSTRAINT FK_RepairTypeCode FOREIGN KEY (RepairTypeCode) REFERENCES RepairTypeCodes,
CONSTRAINT FK_CustId FOREIGN KEY (CustId) REFERENCES Customers
);

CREATE TABLE RepairItems(
RepairId numeric(5) NOT NULL,
PartId numeric(5) NOT NULL,
Price numeric(6,2) DEFAULT(0.00),
QuantityUsed numeric(3) NOT NULL,
Status varchar2(1) DEFAULT('U') NOT NULL,
CONSTRAINT PK_Repair PRIMARY KEY (RepairId,PartId),
CONSTRAINT FK_RepairId FOREIGN KEY (RepairId) REFERENCES Repairs,
CONSTRAINT FK_PartId FOREIGN KEY (PartId) REFERENCES Parts
);
