<link rel="stylesheet" href="CPURepairSYS.css">
<?php 
  include "header.html";
  include "nav.html";
  require 'Validate.Inc.php';
  require 'DBConnectinc.php';
  $pdo = DBConnect();
  ?>
  
  <h1>Add Part</h1>
  <p> Enter Part details below to add a part</p>

  
<form action="addPart.php" method="post">                
        Description: <input type="text" name="cdesc"   value = ""><br>
        Price: <input type="text" name="cprice" ><br>
        Quantity: <input type="text" name="cquantity" ><br>
        Type: <label for="types">Choose a type:</label>
  <select name="ctype">
    <option value="Processor">Processor</option>
    <option value="Graphics Card">Graphics Card</option>
    <option value="Fan">Fan</option>
    <option value="Case">Case</option>
    <option value="Battery">Battery</option>
    <option value="Power Supply">Power Supply</option>
    <option value="MotherBoard">MotherBoard</option>
    <option value="CPU Cooler">CPU Cooler</option>
    <option value="RAM">RAM</option>
    <option value="Storage Device">Storage Device</option>
    <option value="Wifi Adapter">Wifi Adapter</option>
    <option value="Screen">Screen</option>
  </select><br>

        <input type="submit" name="submitdetails" value="SUBMIT" >
     </form>
 </body>
</html>


<?php
 

  
if (isset($_POST['submitdetails'])) {
    try {
        $cdesc = validate($_POST['cdesc']);
        $cprice = validate($_POST['cprice']);
        $cquantity = validate($_POST['cquantity']);
        $ctype = $_POST['ctype'];

        if (
            empty($cdesc) || 
            empty($cprice) || 
            empty($cquantity) || 
            !is_numeric($cprice) || 
            !is_numeric($cquantity)
        ) {
?><p>You did not complete the insert form correctly</p><?php
        } 


else{
        echo"test";

  
$sql = "INSERT INTO Parts (description, price, quantity, type, image) VALUES (:cdesc, :cprice, :cquantity, :ctype, :cimage)";
    
    $stmt = $pdo->prepare($sql);
    
    $stmt->bindValue(':cdesc', $cdesc);
    $stmt->bindValue(':cprice', $cprice);
    $stmt->bindValue(':cquantity', $cquantity);
    $stmt->bindValue(':ctype', $ctype);
        $stmt->bindValue(':cimage', "Images/".$ctype.".png");

    

    $stmt->execute();
        echo"test";

    
?><p>Added! Try adding another</p>
        <?php    }
} 
catch (PDOException $e) { 
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
        echo $output;

} 
} 

 ?>
