<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <meta charset='utf-8'>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="CPURepairSYS.css">
  </head>
  <body>
  <?php 
  include "header.html";
  include "nav.html";
    require 'DBConnectinc.php';
      require 'Validate.Inc.php';

  $pdo = DBConnect();
  ?>


  <h1>Home</h1>
<p>Welcome to CPURepairSYS! Enter Part details below to view the description of parts</p>


 <form action="index.php" method="post">
        Enter Part Description <input type="text" name="partDesc">               
        Enter Part Type: <select name="parttype">
    <option value="Processor">Processor</option>
    <option value="Graphics Card">Graphics Card</option>
    <option value="Fan">Fan</option>
    <option value="Case">Case</option>
    <option value="Battery">Battery</option>
    <option value="Power Supply">Power Supply</option>
    <option value="MotherBoard">MotherBoard</option>
    <option value="CPU Cooler">CPU Cooler</option>
    <option value="RAM">RAM</option>
    <option value="Storage Device">Storage Device</option>
    <option value="Wifi Adapter">Wifi Adapter</option>
    <option value="Screen">Screen</option>
  </select><br>
  <input type="hidden" name="RepairId"  value = "<?php echo($crepairId) ?>">
  <input type="hidden" name="CustId"  value = "<?php echo($ccustId)?>">
  <input type="hidden" name="totalprice"  value = "<?php echo($totalprice) ?>">
  <input type="hidden" name="idvalues"  value = "<?php echo($idvalues) ?>">

        <input type="submit" name="searchPart" value="SUBMIT" >
     </form><?php
  

  if (isset($_POST['searchPart'])) {

  try { 
    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $cpartdesc = validate($_POST['partDesc']);
    $cparttype = $_POST['parttype'];
    $totalprice = $_POST['totalprice'];
    $idvalues = $_POST['idvalues'];

    if ($cpartdesc == '' || !is_string($cpartdesc))
    {
           ?><p>You did not complete the insert form correctly</p><?php exit;
                  }

    $sql = 'Select Description,Image From Parts WHERE Description LIKE "%":cpartdesc"%" AND Type = :cparttype';


    $result = $pdo->prepare($sql);
    $result->bindValue(':cpartdesc', $cpartdesc);
    $result->bindValue(':cparttype', $cparttype);
    $result->execute();

    while ($row = $result->fetch()) { 
           ?><p>Part Description: <?php echo($row['Description']); ?></p> 
            <img src="<?php echo($row['Image']) ?>"> <?php                  //All images sourced from Pixbay

    }
    
    if(!$row = $result->fetch()){
    ?><p>No data found</p><?php
    }
  }

  

  catch (PDOException $e) { 
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
  } 

  }


 ?>
