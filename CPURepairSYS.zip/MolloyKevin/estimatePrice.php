<?php 
  include "header.html";
  include "nav.html";
  require 'DBConnectinc.php';
    require 'Validate.Inc.php';

  $pdo = DBConnect();
  ?>
<!DOCTYPE html>
<html>
<head>
  <meta name="generator" content="HTML Tidy for HTML5 for Windows version 5.6.0">
  <link rel="stylesheet" href="CPURepairSYS.css">
  <title></title>
</head>
<body>

  <h1>Estimate Price</h1>
  <p> Search for a Repair below to begin estimating the price</p>
  <form action="estimatePrice.php" method="post">
    Enter description of repair<input type="text" name="repairDescription"> <input type="submit"
    name="searchRepair" value="SUBMIT">
  </form>
  <?php

  if (isset($_POST['searchRepair'])) {
    $totalprice = 0;
    $idvalues ="";

    
               
  try { 
    $cdesc = validate($_POST['repairDescription']);
    if ($cdesc == '' || !is_string($cdesc))
    {
           ?><p>You did not complete the insert form correctly</p><?php exit;


                  }


  $sql = 'SELECT count(Description) FROM Repairs where Description LIKE "%":cdesc"%"';      



  $result = $pdo->prepare($sql);
  $result->bindValue(':cdesc', $cdesc); 
  $result->execute();



  if($result->fetchColumn() > 0) {

    $sql = 'SELECT RepairId, CustId, Description FROM Repairs WHERE Description LIKE "%":cdesc"%" AND Status = "L"';   

    $result = $pdo->prepare($sql);
    $result->bindValue(':cdesc', $cdesc);  
    $result->execute();


  while ($row = $result->fetch()) { 
        ?><form  method='post' action='estimatePrice.php' >Repair Description: <?php echo($row['Description'])?> <input type='hidden' name='RepairId' value = <?php echo($row['RepairId']) ?> >
        <input type='hidden' name='CustId' value = "<?php echo($row['CustId'])?>">
        <input type='hidden' name='totalprice' value = "<?php echo($totalprice)?>">
        <input type='hidden' name='idvalues' value = "<?php echo($idvalues)?>" >
        <input type='submit' name='estimatePrice' value='Estimate Price' > </form><br> <?php
 
         
   }
  }
  else {
           ?><p>No rows matched the query</p><?php
    }
    
    
    }

  catch (PDOException $e) { 
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
  }  

  }

  if (isset($_POST['estimatePrice']) || isset($_POST['no']) || isset($_POST['continue']) ) {
    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $totalprice = $_POST['totalprice'];
    $idvalues = $_POST['idvalues'];



  ?><form action="estimatePrice.php" method="post">
        Enter Part Description <input type="text" name="partDesc">               
        Enter Part Type: <select name="parttype">
    <option value="Processor">Processor</option>
    <option value="Graphics Card">Graphics Card</option>
    <option value="Fan">Fan</option>
    <option value="Case">Case</option>
    <option value="Battery">Battery</option>
    <option value="Power Supply">Power Supply</option>
    <option value="MotherBoard">MotherBoard</option>
    <option value="CPU Cooler">CPU Cooler</option>
    <option value="RAM">RAM</option>
    <option value="Storage Device">Storage Device</option>
    <option value="Wifi Adapter">Wifi Adapter</option>
    <option value="Screen">Screen</option>
  </select><br>
  <input type="hidden" name="RepairId"  value = "<?php echo($crepairId) ?>">
  <input type="hidden" name="CustId"  value = "<?php echo($ccustId)?>">
  <input type="hidden" name="totalprice"  value = "<?php echo($totalprice) ?>">
  <input type="hidden" name="idvalues"  value = "<?php echo($idvalues) ?>">

        <input type="submit" name="searchPart" value="SUBMIT" >
     </form><?php
  }

  if (isset($_POST['searchPart'])) {

  try { 
    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $cpartdesc = validate($_POST['partDesc']);
    $cparttype = $_POST['parttype'];
    $totalprice = $_POST['totalprice'];
    $idvalues = $_POST['idvalues'];

    if ($cpartdesc == '' || !is_string($cpartdesc))
    {
           ?><p>You did not complete the insert form correctly</p><?php
                  }

    $sql = 'Select PartId, Price,Description,Quantity From Parts WHERE Description LIKE "%":cpartdesc"%" AND Type = :cparttype';


    $result = $pdo->prepare($sql);
    $result->bindValue(':cpartdesc', $cpartdesc);
    $result->bindValue(':cparttype', $cparttype);
    $result->execute();
    
    if(!$row = $result->fetch()){
               ?><p>You did not complete the insert form correctly. Click <a href='estimatePrice.php'> here</a> to restart</p><?php
                exit;
    }

    while ($row = $result->fetch()) { 
        
        ?><form  method='post' action='estimatePrice.php' >                
         <?php echo("Part Description: ".$row['Description']."
         Part Price: ".$row['Price']) ?>
          <input type = 'hidden' name = 'Price' value = '<?php echo($row['Price']) ?>' > 
          <input type = 'hidden' name = 'Quantity' value = '<?php echo($row['Quantity']) ?>' > 

         
  <input type="hidden" name="RepairId"  value = "<?php echo($crepairId) ?>">
  <input type="hidden" name="CustId"  value = "<?php echo($ccustId)?>">
  <input type="hidden" name="totalprice"  value = "<?php echo($totalprice) ?>">
  <input type="hidden" name="idvalues"  value = "<?php echo($idvalues) ?>">


         <input type='hidden' name='PartId'  value = '<?php echo($row['PartId']) ?>' >
                <input type='submit' name='confirmation' value='Select Part' >
  </form><br><?php
   
    
  }

  }

  catch (PDOException $e) { 
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
  } 

  }


  if (isset($_POST['confirmation'])) {

    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $cpartid = $_POST['PartId'];
    $cprice = $_POST['Price'];
    $totalprice = $_POST['totalprice'];
    $idvalues = $_POST['idvalues'];
    
    //Not strictly neccessary but a safeguard in case a quantity of 0 gets inserted mid way through a loop
    $qty = $_POST['Quantity'];
    if ($qty == 0) {
    	?><p>Error. Quantity is 0. Click <a href='estimatePrice.php'> here</a> to reset to restart</p><?php
        exit;
    }
    
    


    
    ?><form method='post' action='estimatePrice.php'>
         <p>You are about to add price : <?php echo($cprice) ?> to the current price of repair: <?php echo($totalprice) ?> Continue?</p><br>
    
         <input type = 'hidden' name = 'Price' value = '<?php echo($cprice) ?>' > 
         <input type="hidden" name="RepairId"  value = "<?php echo($crepairId) ?>">
         <input type="hidden" name="CustId"  value = "<?php echo($ccustId)?>">
         <input type="hidden" name="totalprice"  value = "<?php echo($totalprice) ?>">
         <input type="hidden" name="idvalues"  value = "<?php echo($idvalues) ?>">
         <input type='hidden' name='PartId'  value = '<?php echo($cpartid) ?>' >

    <input type='submit' name='updatingPrice' value='Yes'>
    <input type='submit' name='no' value='No'><?php
    
  }

    if (isset($_POST['updatingPrice'])) {
    
    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $cpartid = $_POST['PartId'];
    $cprice = $_POST['Price'];
    $totalprice = $_POST['totalprice'];
    $idvalues = $_POST['idvalues'];


    
    
    $idvalues .= $cpartid . " ";
  
    $totalprice = $totalprice + $cprice;
    echo("<br>Total Price: ".$totalprice);


    $sql = 'Select Quantity From Parts WHERE PartId = :cpartid';


    $result = $pdo->prepare($sql);
    $result->bindValue(':cpartid', $cpartid);
    $result->execute();
    
    while ($row = $result->fetch()) { 
        $quantity = $row['Quantity'];
     }
     
     if($quantity - 1 == 0){
     $sql = "Update Parts set status = 'O', quantity = 0  WHERE PartId = :cpartid";


    $result = $pdo->prepare($sql);
    $result->bindValue(':cpartid', $cpartid);
    $result->execute();
    ?><p><br>Part is now out of stock</p><?php
     }
    
  


    ?><form method='post' action='estimatePrice.php'>
        <p>Price Updated. Current price is: <?php echo($totalprice) ?> Add more parts to repair?</p><br>
    
         <input type="hidden" name="RepairId"  value = "<?php echo($crepairId) ?>">
         <input type="hidden" name="CustId"  value = "<?php echo($ccustId)?>">
         <input type="hidden" name="totalprice"  value = "<?php echo($totalprice) ?>">
         <input type="hidden" name="idvalues"  value = "<?php echo($idvalues) ?>">
    
    <input type='submit' name='continue' value='Yes'>
    <input type='submit' name='FINAL' value='No'><?php
    
  }

  if (isset($_POST['FINAL'])) {
    $crepairId = $_POST['RepairId'];
    $ccustId = $_POST['CustId'];
    $idvalues = $_POST['idvalues'];
    $totalprice = $_POST['totalprice'];

    $qtys = array();
    
    
    $partids = array();
    $storage = null;
    for($i=0;$i<strlen($idvalues);$i++){     //i=0, idvalues = 12 3 24 54 2
        $storage .= $idvalues[$i];          //idvalues[i],storage == 1 
        $j = $i+1;                          //j=1
        while($idvalues[$j] != " ")         //while idvalues[j] is not a space (currently true because idvalues[1] == 2)
        {
        $storage .= $idvalues[$j];          //append idvalues[j] to the storage, storage == 12
        $j++;                               //increment j
        }
        $partids[] = $storage;              //once the character infront of idvalues[j] is a space (once we reach the end of the current part id), put the value into the array
        $i = $j;                            //Sets i to j + 1 (sets i to the index after the space{the next part id} )
        $storage=null;                      //resets storage
    }
    $check = 0;
    while($check < count($partids))         //Sets qty to 1
    {
    $qtys[$check]=1;
    $check++;
    }
    
    

    
    for ($i = 0; $i < count($partids); $i++) {
    for ($j = $i + 1; $j < count($partids); $j++) {

        
                                                // Check if partids ==
        if ($partids[$i] == $partids[$j]) {

            
                                                // Increments i
            $qtys[$i] += $qtys[$j];
            
                                                // Removes records in both at j
            array_splice($partids, $j, 1);
            array_splice($qtys, $j, 1);
            
            $j--;                               // Decrement j
        }
    }
}




    
     for($i = 0; $i < count($partids); $i++){
    $currentPartId = $partids[$i];
          

          
           $sql = 'Select Price From Parts WHERE PartId = :cpartid';


            $result = $pdo->prepare($sql);
            $result->bindValue(':cpartid', $currentPartId);
            $result->execute();
            $partprice = 0;
            while ($row = $result->fetch()) { 
                $partprice = $row['Price'];
            };
          //Inserts data to RepairItems
         
          $sql = " INSERT INTO RepairItems (PartId, RepairId, Cost, QuantityUsed) VALUES(:cpartid,:crepairid,:ccost,:cquantity)";
          echo($sql);
          echo("RepairItems");


          $result = $pdo->prepare($sql);
          $result->bindValue(':cpartid', $currentPartId);
          $result->bindValue(':crepairid', $crepairId);
          $result->bindValue(':ccost', $partprice * $qtys[$i]);
          $result->bindValue(':cquantity', $qtys[$i]);


          $result->execute();
          
          //Decrements part quantity
          $sql = "UPDATE Parts SET Quantity = Quantity - :cquantity WHERE PartId = :cpartid";


          $result = $pdo->prepare($sql);
          $result->bindValue(':cpartid', $currentPartId);
          $result->bindValue(':cquantity', $qtys[$i]);

          $result->execute();
          echo("Quantity");

          
         } //END OF LOOP
          //Updates price
          
          $sql = "UPDATE Repairs SET Status = 'E', Price = :cprice  WHERE RepairId = :crepairid";


          $result = $pdo->prepare($sql);
          $result->bindValue(':cprice',$totalprice);
          $result->bindValue(':crepairid', $crepairId);

          $result->execute();
          
          
            ?><p>The total price is <?php echo($totalprice); ?>. The Customer has been contacted. Click<a href='estimatePrice.php'> here</a> to reset</p><?php
          
  }


  ?>
</body>
</html>
