<?php
function buildSelect($options, $chosen) {

$select = ('<select name="newType">');
$option;
 
 for ($i = 0; $i < count($options); $i++) {
        $option = ('<option value="' . $i . '">' . $options[$i] . '</option>');
        if ($options[$i] == $chosen) {
             $option = ('<option value="' . $i . '" selected>' . $options[$i] . '</option>');
        }
        $select = $select . ($option);
    }
    
    $select = $select . '</select>';
    
    return $select;

}

?>


