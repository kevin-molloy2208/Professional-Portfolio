<?php
  require 'DBConnectinc.php';
    require 'Validate.Inc.php';

  $pdo = DBConnect();
  
if (isset($_POST['submitdetails'])) { 
try { 

$sql = 'SELECT count(*) FROM parts where partid = :partid';
$result = $pdo->prepare($sql);
$result->bindValue(':partid', $_POST['partid']); 
$result->execute();
if($result->fetchColumn() > 0) 
{
    $sql = 'SELECT * FROM Parts where partid = :partid';
    $result = $pdo->prepare($sql);
    $result->bindValue(':partid', $_POST['partid']); 
    $result->execute();
while ($row = $result->fetch()) { 
        ?> <p> <?php echo($row['Description']);echo($row['Price']) ?>Are you sure you want to delete?</p>
	  <form action="deletePart.php" method="post">
            <input type="hidden" name="id" value="<?php echo($row['PartId'])?>"> 
            <input type="submit" value="Yes Delete" name="delete">
        </form><?php
              }
}
else {
      print "No rows matched the query.";
    }} 
catch (PDOException $e) { 
$output = 'Unable to connect to the database server: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(); 
}
}
?>

