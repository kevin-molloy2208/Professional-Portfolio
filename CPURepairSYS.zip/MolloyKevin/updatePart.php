    <link rel="stylesheet" href="CPURepairSYS.css">
<?php 
  include "header.html";
  include "nav.html";
  require "selectedDropDown.inc.php";
  require 'DBConnectinc.php';
    require 'Validate.Inc.php';

  $pdo = DBConnect();

  ?>
  <h1>Update Part Details</h1>
  <p> Search for a Part below to update a part</p>

<form action="updatePart.php" method="post">                
        Enter Part Type: <select name="ctype">
    <option value="Processor">Processor</option>
    <option value="Graphics Card">Graphics Card</option>
    <option value="Fan">Fan</option>
    <option value="Case">Case</option>
    <option value="Battery">Battery</option>
    <option value="Power Supply">Power Supply</option>
    <option value="MotherBoard">MotherBoard</option>
    <option value="CPU Cooler">CPU Cooler</option>
    <option value="RAM">RAM</option>
    <option value="Storage Device">Storage Device</option>
    <option value="Wifi Adapter">Wifi Adapter</option>
    <option value="Screen">Screen</option>
  </select><br>
        <input type="submit" name="submitdetails" value="SUBMIT" >
     </form>
 </body>
</html>


<?php

if (isset($_POST['updateFinal'])) {
    $cdesc = validate($_POST['newDesc']);
    $cprice = validate($_POST['newPrice']);
    $cstatus = validate($_POST['newStatus']);
    $cquantity = validate($_POST['newQuantity']);
    $ctype = $_POST['newType'];
    $cid = $_POST['partId'];


    
    if (!is_string($cdesc)==1  or !is_numeric($cprice)==1 or !is_string($cstatus)==1  or !is_numeric($cquantity)==1 or !is_string($ctype) == 1)
    {
?><p>You did not complete the insert form correctly</p>
        <?php         
                 }
    else{
  
        $sql = 'UPDATE Parts SET
        Description = :cdesc,
        Price = :cprice,
        Status = :cstatus,
        Quantity = :cquantity,
        Type = :ctype
        WHERE PartId = :cid';
    
        $result = $pdo->prepare($sql);
        $result->bindValue(':cid', $cid);
        $result->bindValue(':cdesc', $cdesc);
        $result->bindValue(':cprice', $cprice);
        $result->bindValue(':cstatus', $cstatus);
        $result->bindValue(':cquantity', $cquantity);
        $result->bindValue(':ctype', $ctype);
        $result->execute();
        
            ?><p>Done! Click<a href='updatePart.php'> here</a> to reset</p>
            <?php

    
    }
}

if (isset($_POST['updateDetails'])) {
    $id = $_POST['id'];
    
    

    $sql = 'SELECT partid,description,price,status,quantity,type FROM Parts WHERE partid = :cid';
    
    $result = $pdo->prepare($sql);
    $result->bindValue(':cid', $id); 
    $result->execute();
    
    while ($row = $result->fetch()) { 
        $chosen = $row['type'];
        $types = array("Processor","Graphics Card","Fan","Case","Battery","Power Supply","MotherBoard","CPU Cooler","RAM","Storage Device","Wifi Adapter","Screen");

        
      
        ?><form method='post'>                
          Enter Part Description: <input type='text' name='newDesc'   value = "<?php echo($row['description'])?>"><br>
          Enter Part Price: <input type='text' name='newPrice'   value = "<?php echo($row['price'])?>"><br>
          Enter Part Status: <input type='text' name='newStatus'   value = "<?php echo($row['status'])?>"><br>
          Enter Part Quantity: <input type='text' name='newQuantity'   value = "<?php echo($row['quantity'])?>"><br>
          Enter Part Type <?php echo(buildSelect($types, $chosen) )?><br>
          <input type = 'hidden' name=partId value = "<?php echo($row['partid'])?>">
          <input type='submit' name='updateFinal' value='UPDATE' >
       </form>
     <?php
     
      
   }
   
   }
    
    

  
if (isset($_POST['submitdetails'])) {    
               
try { 
    $ctype = validate($_POST['ctype']);



  
$sql = 'SELECT count(Type) FROM Parts where Type = :ctype';      

     

$result = $pdo->prepare($sql);
$result->bindValue(':ctype', $ctype); 
$result->execute();


if($result->fetchColumn() > 0) {

    $sql = 'SELECT partid,description,price,status,quantity,type FROM Parts WHERE type = :ctype';
    $result = $pdo->prepare($sql);
    $result->bindValue(':ctype', $ctype); 
    $result->execute();


while ($row = $result->fetch()) { 
        
        ?><form  method='post' >                
         Part Description: <?php echo($row['description']) ?> <input type='hidden' name='id'  value = <?php echo($row['partid']) ?> >
                <input type='submit' name='updateDetails' value='UPDATE' >
</form><br>
     <?php
    
      
   }
}
else {
      ?><p>No rows matched query</p>
        <?php       
    }
    
    
    }

catch (PDOException $e) { 
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
}  

}

 ?>
