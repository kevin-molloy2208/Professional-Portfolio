<link rel="stylesheet" href="CPURepairSYS.css">
<?php 
  include "header.html";
  include "nav.html";
  require 'DBConnectinc.php';
    require 'Validate.Inc.php';

  $pdo = DBConnect();
  ?>
  
    <h1>Delete Part</h1>
  <p> Enter Part Id below to delete a part</p>
  
<form action="deletePart.php" method="post">                
        Enter Part ID: <input type="text" name="partid" ><br>
        <input type="submit" name="submitdetails" value="SUBMIT" >
     </form>

 </body>
</html>

<?php

if (isset($_POST['submitdetails'])) { 
try { 
if(is_numeric($_POST['partid']) ){
$sql = 'SELECT count(*) FROM parts where partid = :partid';
$result = $pdo->prepare($sql);
$result->bindValue(':partid', validate($_POST['partid'])); 
$result->execute();
if($result->fetchColumn() > 0) 
{
    $sql = 'SELECT * FROM Parts where partid = :partid';
    $result = $pdo->prepare($sql);
    $result->bindValue(':partid', validate($_POST['partid'])); 
    $result->execute();
while ($row = $result->fetch()) { 
        echo $row['Description'] . ' ' . $row['Price']  ?><p>Are you sure you want to delete?</p> <?php 
	  ?><form action="deletePart.php" method="post">
            <input type="hidden" name="x" value="<?php echo($row['PartId']) ?>"> 
            <input type="submit" value="Yes Delete" name="delete">
	        <button onclick="location.href='deletePart.php'">No</button>
        </form><?php
              }
}
else {
      print "No rows matched the query.";
    }}
    else{?><p>Insert form completed incorrectly</p><?php } 
    }
catch (PDOException $e) { 
$output = 'Unable to connect to the database server: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(); 
}
}  

if(isset($_POST['delete'])){
$cid = $_POST['x'];

try { 

$sql = 'DELETE FROM Parts WHERE Partid = :Partid';
$result = $pdo->prepare($sql);
$result->bindValue(':Partid', $cid); 
$result->execute();
?><p>You just deleted part Number <?php echo($cid) ?> <br> Click<a href='deletePart.php'> here</a> to reset form </p><?php
} 
catch (PDOException $e) { 
if ($e->getCode() == 23000) {
          ?><p> Delete Failed. Record is used in other tables. Click <a href='deletePart.php'> here</a> to reset <?php 
     }
} 
}
?>
