    <?php 
  include "header.html";
  include "nav.html";
  require 'DBConnectinc.php';
  require 'Validate.Inc.php';

  $pdo = DBConnect();
  ?>
  
    <link rel="stylesheet" href="CPURepairSYS.css">

  
    <h1>Log Repair</h1>
    <p> Enter Customer Details below to begin</p>
  
  <form action="logRepair.php" method="post">                
        
        Does the customer have an account with us?<input type="submit" name="preexisting" value=" Yes " >
                                                  <input type="submit" name="nonexisting" value=" No " >
     </form>
 </body>
</html>


 <?php  
    if (isset($_POST['logRepairFinal'])) {
    $cdesc = validate($_POST['newDesc']);
    $ccustid = validate($_POST['custId']);

 
    $sql = "INSERT INTO Repairs (description,status,custid) VALUES(:cdesc,'L',:ccustid)";


    $result = $pdo->prepare($sql);
    $result->bindValue(':cdesc', $cdesc);
    $result->bindValue(':ccustid', $ccustid);
    $result->execute();
    
        ?><p>Done! Click<a href='logRepair.php'> here</a> to reset</p><?php

    
    
}

    if (isset($_POST['logRepair'])) {
            $custid = $_POST['custId'];
 

            ?><form method='post' action='logRepair.php'>                
                    Enter Repair Description: <input type='text' name='newDesc'><br>
                    <input type = 'hidden' name=custId value = "<?php echo($custid)?>">
                    <input type='submit' name='logRepairFinal' value='Log Repair' >
                 </form>
               
               <?php
      
            }
  
  if (isset($_POST['customerPhone'])) {            
    $phone = validate($_POST['preexistPhone']);

      
      
            $phone = str_replace(" ", "", $phone);

      if(!is_numeric($phone)){
            ?><p>Incorrect Phone Number </p><?php
            exit;      }
      
      $phone = substr_replace( $phone, " ", 3, 0 );
            $phone = substr_replace( $phone, " ", 7, 0 );



        if(strlen($phone) != 12){
            ?><p>Incorrect Phone Number </p><?php
            exit;
        }
    
    $sql = "SELECT * from Customers WHERE Phone = :cphone";
    
    $result = $pdo->prepare($sql);
    $result->bindValue(':cphone', $phone); 

    $result->execute();
    
  
            
            if($row = $result->fetch()){
 
        ?><form method='post' action='logRepair.php'>                
          <p>Customer Name : <?php echo($row['FName']); echo($row['SName']); ?> <br> Is this the correct customer?</p>
          <input type="hidden" name="custId" value="<?php echo($row['CustId']) ?>">
          <input type='submit' name='logRepair' value='Yes'>
          <input type='submit' name='incorrectDetails' value='No'>
          </form>   <?php
   }
   else{    
   ?><p>Customer not found.Click<a href='logRepair.php'> here</a> to reset</p><?php
}
    
    }

  
  if (isset($_POST['preexisting']) || isset($_POST['incorrectDetails'])) {


        ?><form method='post' action='logRepair.php'>                
          Enter Customer's Phone Number: <input type='text' name='preexistPhone'><br>

          <input type='submit' name='customerPhone' value='Enter' >
       </form>
     <?php
         
   }
    
    
    if (isset($_POST['nonexisting'])) {


        ?><form method='post' action='logRepair.php'>              
          Enter Customer's First Name : <input type='text' name='fname'><br>
          Enter Customer's Second Name : <input type='text' name='sname'><br>
          Enter Customer's Phone : <input type='text' name='phone'><br>
          Enter Customer's Email : <input type='text' name='email'><br>


          <input type='submit' name='addCustomer' value='Enter' >
       </form><?php
       
    
     }
     if (isset($_POST['addCustomer'])) {

    $cfname = validate($_POST['fname']);
    $csname = validate($_POST['sname']);
    $cphone = validate($_POST['phone']);
    $cemail = validate($_POST['email']);
    
    
          
            $cphone = str_replace(" ", "", $cphone);

      if(!is_numeric($cphone)){
            ?><p>Incorrect Phone Number </p><?php
            exit;      }
      
      $cphone = substr_replace( $cphone, " ", 3, 0 );
            $cphone = substr_replace( $cphone, " ", 7, 0 );



        if(strlen($cphone) != 12){
            ?><p>Incorrect Phone Number </p><?php
            exit;
        }
    
    if (is_string($cfname)==1 and is_string($csname)==1 and is_string($cemail)==1){
    $sql = "INSERT INTO Customers (fname,sname,phone,email) VALUES(:cfname,:csname,:cphone,:cemail)";




    $result = $pdo->prepare($sql);
    $result->bindValue(':cfname', $cfname);
    $result->bindValue(':csname', $csname);
    $result->bindValue(':cphone', strval(($cphone)));
    $result->bindValue(':cemail', $cemail);
    $result->execute();
    


    $sql = 'SELECT custid FROM Customers WHERE phone = :cphone';
    
    $result = $pdo->prepare($sql);
    $result->bindValue(':cphone', $cphone); 
    $result->execute();
    
     while ($row = $result->fetch()) { 

    ?><form method='post' action='logRepair.php'>   
        
        Customer added! Click continue to begin logging the repair 
        <input type = 'hidden' name=custId value = "<?php echo($row['custid'])?>"><br>
        <input type='submit' name='logRepair' value = 'continue'>
        </form>
    <?php
      
   }}
   else{
   ?><p>You did not complete the insert form correctly</p><?php
   }

}
  ?>
  
