-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: CPURepairSYS
-- ------------------------------------------------------
-- Server version	11.7.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `CustId` int(11) NOT NULL AUTO_INCREMENT,
  `FName` char(15) NOT NULL,
  `SName` char(15) NOT NULL,
  `Phone` char(12) NOT NULL,
  `Email` char(30) DEFAULT NULL,
  PRIMARY KEY (`CustId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Leon','Kennedy','089 273 8102','lkennedy@email.com'),(2,'Peter','Parker','086 273 6192','pparker@email.com'),(3,'Bat','Man','087 837 7621','vengence@email.com'),(4,'Charlie','Jameson','083 547 2458','CharlieJ@email.com'),(5,'Diana','Williams','081 030 7427','DianaW@email.com'),(6,'George','Davis','087 340 6900','GeorgeD@email.com');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parts` (
  `PartId` int(11) NOT NULL AUTO_INCREMENT,
  `Description` char(100) NOT NULL,
  `Price` decimal(5,2) NOT NULL,
  `Status` enum('A','O','D') NOT NULL,
  `Quantity` tinyint(4) DEFAULT NULL,
  `Type` char(15) NOT NULL,
  `Image` char(40) DEFAULT 'Images/Default.png',
  PRIMARY KEY (`PartId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parts`
--

LOCK TABLES `parts` WRITE;
/*!40000 ALTER TABLE `parts` DISABLE KEYS */;
INSERT INTO `parts` VALUES (1,'Intel Core i9',624.99,'A',6,'Processor','Images/Processor.png'),(2,'iCUE link RX120 Fan',129.00,'A',28,'Fan','Images/Fan.png'),(3,'HyperTech RAM Module X6',179.12,'D',12,'RAM','Images/RAM.png'),(4,'CoolMaster Cooling System Pro7',11.77,'O',0,'CPU Cooler','Images/CPU Cooler.png'),(5,'SpeedX RAM Module X8',63.87,'A',7,'RAM','Images/RAM.png'),(6,'VoltPower Battery Pack V9',53.57,'D',29,'Battery','Images/Battery.png'),(7,'PixelEdge Graphics Card GX10',119.68,'A',38,'Graphics Card','Images/Graphics Card.png'),(8,'PrimeTech Motherboard Pro11',29.99,'O',0,'MotherBoard','Images/MotherBoard.png'),(9,'VoltPower Battery Pack V12',129.77,'O',0,'Battery','Images/Battery.png'),(10,'PixelEdge Graphics Card GX15',123.69,'D',2,'Graphics Card','Images/Graphics Card.png'),(11,'SpeedX RAM Module X17',60.69,'D',3,'RAM','Images/RAM.png'),(12,'VoltPower Battery Pack V18',34.67,'A',7,'Battery','Images/Battery.png'),(13,'StorEdge Storage Drive S19',127.02,'A',40,'Storage Device','Images/Storage Device.png'),(14,'HyperTech RAM Module X20',86.51,'O',0,'RAM','Images/RAM.png'),(15,'VoltPower Battery Pack V21',98.87,'A',15,'Battery','Images/Battery.png'),(16,'VoltPower Battery Pack V22',72.28,'A',35,'Battery','Images/Battery.png'),(17,'CoreX HyperProcessor 90',197.08,'D',69,'Processor','Images/Processor.png'),(18,'PixelEdge Graphics Card GX24',166.44,'D',40,'Graphics Card','Images/Graphics Card.png'),(19,'PixelEdge Graphics Card GX25',197.32,'O',0,'Graphics Card','Images/Graphics Card.png');
/*!40000 ALTER TABLE `parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairitems`
--

DROP TABLE IF EXISTS `repairitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairitems` (
  `PartId` int(11) NOT NULL,
  `RepairId` int(11) NOT NULL,
  `Cost` decimal(6,2) DEFAULT NULL,
  `QuantityUsed` decimal(3,0) DEFAULT NULL,
  PRIMARY KEY (`PartId`,`RepairId`),
  KEY `RepairId` (`RepairId`),
  CONSTRAINT `repairitems_ibfk_1` FOREIGN KEY (`PartId`) REFERENCES `parts` (`PartId`),
  CONSTRAINT `repairitems_ibfk_2` FOREIGN KEY (`RepairId`) REFERENCES `repairs` (`RepairId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairitems`
--

LOCK TABLES `repairitems` WRITE;
/*!40000 ALTER TABLE `repairitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `repairitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repairs`
--

DROP TABLE IF EXISTS `repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs` (
  `RepairId` int(11) NOT NULL AUTO_INCREMENT,
  `Description` char(100) NOT NULL,
  `Status` enum('L','E','A','C','P') NOT NULL,
  `Price` decimal(6,2) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `CompleteDate` date DEFAULT NULL,
  `CustId` int(11) NOT NULL,
  PRIMARY KEY (`RepairId`),
  KEY `CustId` (`CustId`),
  CONSTRAINT `repairs_ibfk_1` FOREIGN KEY (`CustId`) REFERENCES `customers` (`CustId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs`
--

LOCK TABLES `repairs` WRITE;
/*!40000 ALTER TABLE `repairs` DISABLE KEYS */;
INSERT INTO `repairs` VALUES (1,'Customers laptop is overheating','L',NULL,NULL,NULL,1),(2,'Customer has a storage anomoly','L',NULL,NULL,NULL,2),(3,'WiFi adapter failure and replacement required','L',NULL,NULL,NULL,3),(4,'Faulty screen display causing color distortion','L',NULL,NULL,NULL,4),(5,'Memory module replacement for performance enhancement','L',NULL,NULL,NULL,5),(6,'Battery pack replacement due to charging issues','L',NULL,NULL,NULL,6);
/*!40000 ALTER TABLE `repairs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-04  0:33:24
