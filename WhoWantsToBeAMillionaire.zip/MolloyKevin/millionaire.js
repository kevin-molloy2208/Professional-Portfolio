// JavaScript Document
    let unsortedQuestions = [
        
        {question : "  2+2 = ?" , ans1: "3", ans2: "5", ans3: "7", ans4: "4", correctAns: "4"},
        {question : "  3-(5+2) = ?" , ans1: "4", ans2: "0", ans3: "-4", ans4: "1", correctAns: "-4"},
        {question : "  8*4/2 = ?" , ans1: "16", ans2: "24", ans3: "32", ans4: "8", correctAns: "16"},
        {question : "  5**2 + 17 - ((7**2) + 3) = ?" , ans1: "-10", ans2: "10", ans3: "52", ans4: "42", correctAns: "-10"},
        {question : "  ( ( ((19864 * 382)**2) + 3 )/17 ) * 0 = ?" , ans1: "127463", ans2: "-73", ans3: "Infinity", ans4: "0", correctAns: "0"},
        {question : "  What is the 3rd planet from the sun?" , ans1: "Mercury", ans2: "Venus", ans3: "The Moon", ans4: "Earth", correctAns: "Earth"},
        {question : "  Who of the following were NOT members of the Beatles?" , ans1: "John Lennon", ans2: "Ringo Star", ans3: "Freddie Mercury", ans4: "Paul McCartney", correctAns: "Freddie Mercury"},
        {question : "  Hiccup is the main protaganist in what animated movie series?" , ans1: "How to train your Dragon", ans2: "Shrek", ans3: "Regular Show", ans4: "Adventure Time", correctAns: "How to train your Dragon"},
        {question : "  Who played the Joker in 2008's hit movie 'The Dark Knight'?" , ans1: "Joaqin Phoenix", ans2: "Christian Bale", ans3: "Gary Oldman", ans4: "Heath Ledger", correctAns: "Heath Ledger"},
        {question : "  What Mythological Creature is typically associated with rainbows?" , ans1: "Bigfoot", ans2: "The Loch Ness Monster", ans3: "Unicorn", ans4: "Minotaur", correctAns: "Unicorn"},
        {question : "  What is a group of crows called?" , ans1: "A Murder", ans2: "A Pride", ans3: "A Gaggle", ans4: "A Hoard", correctAns: "A Murder"},
        {question : "  In the song '12 Days of Christmas', how many lords were said to be leaping?" , ans1: "9", ans2: "8", ans3: "10", ans4: "11", correctAns: "10"},
        {question : "  What kind of animal is Sonic, the popular video game character?" , ans1: "Fox", ans2: "Echidna", ans3: "Hedgehog", ans4: "Bat", correctAns: "Hedgehog"},
        {question : "  What programming language would you use to access Database Tables?" , ans1: "Java", ans2: "JavaScript", ans3: "SQL", ans4: "Python", correctAns: "SQL"},
        {question : "  Who was the 13th President of the United States?" , ans1: "Joe Biden", ans2: "Ronald Regan", ans3: "Donald Trump", ans4: "Millard Fillmore", correctAns: "Millard Fillmore"},
        {question : "  How did comic book character 'Batman', get his powers?" , ans1: "Radioactive Spider Bite", ans2: "He's an Alien", ans3: "He doesn't have powers", ans4: "Fell into a vat of electric eels", correctAns: "He doesn't have powers"},
        {question : "  What is the powerhouse of the cell?" , ans1: "Cytoplasm", ans2: "Chloroplast", ans3: "Ribosome", ans4: "Mitochondria", correctAns: "Mitochondria"},
        {question : "  What type of vehicle is Thomas, a character from a popular kids tv show?" , ans1: "Train", ans2: "Tank", ans3: "Car", ans4: "Helicopter", correctAns: "Train"},
        {question : "  Who is Luke Skywalker's Father?" , ans1: "Darth Vader", ans2: "Yoda", ans3: "Mace Windu", ans4: "Obi Wan Kenobi", correctAns: "Darth Vader"},
        {question : "  What is the name of the Simpson Family's eldest child?" , ans1: "Bart", ans2: "Millhouse", ans3: "Lisa", ans4: "Maggie", correctAns: "Bart"},
        {question : "  What type of rock is Quartzite?" , ans1: "Semi-Permeable", ans2: "Sedimatary", ans3: "Metamorphic", ans4: "Igneous", correctAns: "Metamorphic"},
        {question : "  Who voiced the main protagonist of the Bee Movie?" , ans1: "Jerry Seinfeld", ans2: "Jerry Adams", ans3: "Jerry Smith", ans4: "Jerry Maguire", correctAns: "Jerry Seinfeld"},
        {question : "  What is the Tallest Man-Made Structure?" , ans1: "Eiffel Tower", ans2: "Burj Khalifa", ans3: "The Spire", ans4: "The Empire State Building", correctAns: "Burj Khalifa"},
        {question : "  Where does Spongebob Live?" , ans1: "Bikini Bottom", ans2: "Whoville", ans3: "Narnia", ans4: "Middle Earth", correctAns: "Bikini Bottom"},
        {question : "  How long does it take for the Earth to orbit the Sun" , ans1: "24 Hours", ans2: "27 Days", ans3: "364 Days", ans4: "365.25 Days", correctAns: "365.25 Days"}
        
    ];
    
    
    let roundCount=0;
    let playerStatus = "";
    
    let questionOrder = [];
    let questionIndex = 0;
    let score = "$0";
    let currentPrize = "";
    
    let seenAnswers = []
      

      
     function randomisedQuestions()
        {
          
          //Randomising the question Order
     
          while(questionOrder.length <= 14)
          {
              
              questionIndex = Math.floor(Math.random()*24-1)+1;
              
          
              if(questionOrder.indexOf(questionIndex) === -1)
              {
                  questionOrder.push(questionIndex);
              }
          }
          
          console.log(questionOrder)
        
        }
        
        randomisedQuestions();
        
        
        let randomisedFullQuestions = [];
        
        
          //populating the questions array
  
        for(let i = 0; i<=14; i++)
        {
            randomisedFullQuestions.push(unsortedQuestions[questionOrder[i]]);
        }
        
        for(let j = 0;j<=14;j++){
          console.log(randomisedFullQuestions[j].question);
        }
        console.log(randomisedFullQuestions)
        

        
        function gameLoop(){
        
        let timer = document.getElementById("timer"); 

        let timerCount = 30; 

        let interval = setInterval(() => {
                        timer.innerHTML = timerCount + " seconds left";
                        if (timerCount == 0) {
                            timer.innerHTML = "GAME OVER";
                            showScore('summaryPage.html');
                            clearInterval(interval);
                        } else {
                            timerCount--;
                        }
                    }, 1000);  
           
                let i = 0;
                let roundCount = i+1;
                
                let endWindow;
        
                let playerName = localStorage.getItem("playerName");
                document.getElementById("gameNameBox").innerHTML += (playerName);

        
                let question = randomisedFullQuestions[i].question;
                let ans1 = randomisedFullQuestions[i].ans1;
                let ans2 = randomisedFullQuestions[i].ans2;
                let ans3 = randomisedFullQuestions[i].ans3;
                let ans4 = randomisedFullQuestions[i].ans4;
                let correctAns = randomisedFullQuestions[i].correctAns;
                
                document.getElementById("question").innerHTML += (roundCount + ": " + question);
                document.getElementById("ans1").innerHTML += (ans1);
                document.getElementById("ans2").innerHTML += (ans2);
                document.getElementById("ans3").innerHTML += (ans3);
                document.getElementById("ans4").innerHTML += (ans4);
                
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                let prizeId = 15;
                let colorTracker=15;
                
                document.getElementById("prizes").childNodes[colorTracker].style.backgroundColor = "#FFCC33";   

                //
               
               
                
                
                
                
                
               
                //BUTTON 1
                document.getElementById("ans1").addEventListener("click", function(){
                
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                if(ans1 != randomisedFullQuestions[i].correctAns){
                playerStatus="lose";
                localStorage.setItem("status", playerStatus);
                localStorage.setItem("round_no", roundCount);
                localStorage.setItem("score", score);
                localStorage.setItem("incorrect_question_q", question);
                localStorage.setItem("incorrect_q_answers_q", seenAnswers);
                localStorage.setItem("incorrect_q_correct_answer_q", correctAns);
                clearInterval(interval);
                showScore("summaryPage.html");
                }
                
               
                
                else{
                i++;
                
                
                timerCount=30;
                
                console.log("correct")
                colorTracker--;
                document.getElementById("prizes").childNodes[colorTracker+1].style.backgroundColor = "#102353";
                document.getElementById("prizes").childNodes[colorTracker].style.backgroundColor = "#FFCC33";    

                
                
                console.log("CURRENT PRIZE IS "+currentPrize);
                console.log(colorTracker);
                
                currentPrize = document.getElementById("prizes").childNodes[colorTracker].innerHTML;
                
                if (currentPrize == "$2000" || currentPrize == "$64000"){
                    score = document.getElementById("prizes").childNodes[colorTracker+1].innerHTML;;
                    console.log("CURRENT SCORE IS " + score)
                }
                
                if (currentPrize == "INVISIBLE"){
                localStorage.setItem("round_no" ,roundCount);
                playerStatus="win";
                localStorage.setItem("status", playerStatus);
                score = "1000000";
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");}
                
                
     
                roundCount++;
                
                
                question = randomisedFullQuestions[i].question;
                ans1 = randomisedFullQuestions[i].ans1;
                ans2 = randomisedFullQuestions[i].ans2;
                ans3 = randomisedFullQuestions[i].ans3;
                ans4 = randomisedFullQuestions[i].ans4;
                correctAns = randomisedFullQuestions[i].correctAns;
                
                document.getElementById("question").innerHTML = (roundCount + ": " + question);
                document.getElementById("ans1").innerHTML = (ans1);
                document.getElementById("ans2").innerHTML = (ans2);
                document.getElementById("ans3").innerHTML = (ans3);
                document.getElementById("ans4").innerHTML = (ans4);
                
                document.getElementById("ans1").style.backgroundColor = "#2890d0";
                document.getElementById("ans2").style.backgroundColor = "#2890d0";
                document.getElementById("ans3").style.backgroundColor = "#2890d0";
                document.getElementById("ans4").style.backgroundColor = "#2890d0";
                
                }
                
                    
                }

                )
                ;
                
                
                //BUTTON 2
                
                document.getElementById("ans2").addEventListener("click", function(){
 
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
 
                if(ans2 != randomisedFullQuestions[i].correctAns){
                localStorage.setItem("incorrect_question_q", question);
                localStorage.setItem("incorrect_q_answers_q", seenAnswers);
                localStorage.setItem("incorrect_q_correct_answer_q", correctAns);
                localStorage.setItem("round_no", roundCount);
                playerStatus="lose";
                localStorage.setItem("status", playerStatus);
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");
                }   
                
                
                
                else{
                i++;
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                console.log("correct")
                colorTracker--;
                document.getElementById("prizes").childNodes[colorTracker+1].style.backgroundColor = "#102353";
                document.getElementById("prizes").childNodes[colorTracker].style.backgroundColor = "#FFCC33";   
                
                timerCount=30;
                
                console.log("CURRENT PRIZE IS "+currentPrize);
                console.log(colorTracker);
                
                currentPrize = document.getElementById("prizes").childNodes[colorTracker].innerHTML;
                
                if (currentPrize == "$2000" || currentPrize == "$64000"){
                    score = document.getElementById("prizes").childNodes[colorTracker+1].innerHTML;;
                    console.log("CURRENT SCORE IS " + score)
                }
                
                if (currentPrize == "INVISIBLE"){
                localStorage.setItem("round_no", roundCount);
                playerStatus="win";
                localStorage.setItem("status", playerStatus);
                score = "1000000";
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");}    
                

                roundCount++;
                
                
                question = randomisedFullQuestions[i].question;
                ans1 = randomisedFullQuestions[i].ans1;
                ans2 = randomisedFullQuestions[i].ans2;
                ans3 = randomisedFullQuestions[i].ans3;
                ans4 = randomisedFullQuestions[i].ans4;
                correctAns = randomisedFullQuestions[i].correctAns;
                
                document.getElementById("question").innerHTML = (roundCount + ": " + question);
                document.getElementById("ans1").innerHTML = (ans1);
                document.getElementById("ans2").innerHTML = (ans2);
                document.getElementById("ans3").innerHTML = (ans3);
                document.getElementById("ans4").innerHTML = (ans4);
                
                document.getElementById("ans1").style.backgroundColor = "#2890d0";
                document.getElementById("ans2").style.backgroundColor = "#2890d0";
                document.getElementById("ans3").style.backgroundColor = "#2890d0";
                document.getElementById("ans4").style.backgroundColor = "#2890d0";
                
                }
                }
                
                )
                ;
                
                
                
                //BUTTON 3
                document.getElementById("ans3").addEventListener("click", function(){
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                if(ans3 != randomisedFullQuestions[i].correctAns){
                localStorage.setItem("incorrect_question_q", question);
                localStorage.setItem("incorrect_q_answers_q", seenAnswers);
                localStorage.setItem("incorrect_q_correct_answer_q", correctAns);
                localStorage.setItem("round_no", roundCount);
                playerStatus="lose";
                localStorage.setItem("status", playerStatus);
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");
                } 
                
               
                
                else{
                i++;
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                console.log("correct")
                   
                colorTracker--;
                document.getElementById("prizes").childNodes[colorTracker+1].style.backgroundColor = "#102353";
                document.getElementById("prizes").childNodes[colorTracker].style.backgroundColor = "#FFCC33";   
                
                timerCount=30;
                
                console.log("CURRENT PRIZE IS "+currentPrize);
                console.log(colorTracker);
                
                currentPrize = document.getElementById("prizes").childNodes[colorTracker].innerHTML;
                
                if (currentPrize == "$2000" || currentPrize == "$64000"){
                    score = document.getElementById("prizes").childNodes[colorTracker+1].innerHTML;;
                    console.log("CURRENT SCORE IS " + score)
                }
                
                if (currentPrize == "INVISIBLE"){
                localStorage.setItem("round_no", roundCount);
                playerStatus="win";
                localStorage.setItem("status", playerStatus);
                score = "1000000";
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");}
                
                
                roundCount++;
                
                
                question = randomisedFullQuestions[i].question;
                ans1 = randomisedFullQuestions[i].ans1;
                ans2 = randomisedFullQuestions[i].ans2;
                ans3 = randomisedFullQuestions[i].ans3;
                ans4 = randomisedFullQuestions[i].ans4;
                correctAns = randomisedFullQuestions[i].correctAns;
                
                document.getElementById("question").innerHTML = (roundCount + ": " + question);
                document.getElementById("ans1").innerHTML = (ans1);
                document.getElementById("ans2").innerHTML = (ans2);
                document.getElementById("ans3").innerHTML = (ans3);
                document.getElementById("ans4").innerHTML = (ans4);
                
                document.getElementById("ans1").style.backgroundColor = "#2890d0";
                document.getElementById("ans2").style.backgroundColor = "#2890d0";
                document.getElementById("ans3").style.backgroundColor = "#2890d0";
                document.getElementById("ans4").style.backgroundColor = "#2890d0";
                    
                }
                }
                )
                ;
                
                
                
                //BUTTON 4
                document.getElementById("ans4").addEventListener("click", function(){
                seenAnswers = [ans1, ans2, ans3, ans4];
                localStorage.setItem("question_" + roundCount, question);
                localStorage.setItem("answers_q_" + roundCount, seenAnswers);
                localStorage.setItem("correct_answer_q_" + roundCount, correctAns);
                
                
                if(ans4 != randomisedFullQuestions[i].correctAns){
                localStorage.setItem("incorrect_question_q", question);
                localStorage.setItem("incorrect_q_answers_q", seenAnswers);
                localStorage.setItem("incorrect_q_correct_answer_q", correctAns);
                localStorage.setItem("round_no", roundCount);
                playerStatus="lose";
                localStorage.setItem("status", playerStatus);
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");
                }
                
          
                
                else{
                
                i++;
                
                console.log("correct")
                colorTracker--;
                document.getElementById("prizes").childNodes[colorTracker+1].style.backgroundColor = "#102353";
                document.getElementById("prizes").childNodes[colorTracker].style.backgroundColor = "#FFCC33";  
                
                timerCount=30;

                
                console.log("CURRENT PRIZE IS "+currentPrize);
                console.log(colorTracker);
                
                currentPrize = document.getElementById("prizes").childNodes[colorTracker].innerHTML;
                
                if (currentPrize == "$2000" || currentPrize == "$64000"){
                    score = document.getElementById("prizes").childNodes[colorTracker+1].innerHTML;;
                   console.log("CURRENT SCORE IS " + score)
                }
                
                if (currentPrize == "INVISIBLE"){
                localStorage.setItem("round_no", roundCount);
                playerStatus="win";
                localStorage.setItem("status", playerStatus);
                score = "1000000";
                localStorage.setItem("score", score);
                clearInterval(interval);
                showScore("summaryPage.html");}     
                
                
                
                roundCount++;
                
                question = randomisedFullQuestions[i].question;
                ans1 = randomisedFullQuestions[i].ans1;
                ans2 = randomisedFullQuestions[i].ans2;
                ans3 = randomisedFullQuestions[i].ans3;
                ans4 = randomisedFullQuestions[i].ans4;
                correctAns = randomisedFullQuestions[i].correctAns;
                
                document.getElementById("question").innerHTML = (roundCount + ": " + question);
                document.getElementById("ans1").innerHTML = (ans1);
                document.getElementById("ans2").innerHTML = (ans2);
                document.getElementById("ans3").innerHTML = (ans3);
                document.getElementById("ans4").innerHTML = (ans4);
                
                document.getElementById("ans1").style.backgroundColor = "#2890d0";
                document.getElementById("ans2").style.backgroundColor = "#2890d0";
                document.getElementById("ans3").style.backgroundColor = "#2890d0";
                document.getElementById("ans4").style.backgroundColor = "#2890d0";
                }
                }
                )
                ;
                
                
                
                document.getElementById("fifty").addEventListener("click", function(){
                
                if(ans1 == randomisedFullQuestions[i].correctAns){
                    document.getElementById("ans2").style.backgroundColor = "#FF0000";
                    document.getElementById("ans3").style.backgroundColor = "#FF0000"; 
                }
                
                if(ans2 == randomisedFullQuestions[i].correctAns){
                    document.getElementById("ans4").style.backgroundColor = "#FF0000"; 
                    document.getElementById("ans3").style.backgroundColor = "#FF0000";        
                }
                
                if(ans3 == randomisedFullQuestions[i].correctAns){
                    document.getElementById("ans1").style.backgroundColor = "#FF0000"; 
                    document.getElementById("ans4").style.backgroundColor = "#FF0000"; 
                    
                }
                if(ans4 == randomisedFullQuestions[i].correctAns){
                    document.getElementById("ans1").style.backgroundColor = "#FF0000"; 
                    document.getElementById("ans2").style.backgroundColor = "#FF0000"; 
                }
                
                document.getElementById("fifty").style.opacity = "0%"; 

                
                
                }
                )
                ;
                
                document.getElementById("audience").addEventListener("click", function(){
                
                    let randomButton = [];
                    let randomIndex = 0;
                    
                     while(randomButton.length <= 3)
                     {
                          randomIndex = Math.floor(Math.random()*4-0)+1;
                          
                      
                          if(randomButton.indexOf("ans" + randomIndex) === -1)
                          {
                              randomButton.push("ans" + randomIndex);
                          }
                     }
                    
                     console.log(randomButton[0]);
                     console.log(randomButton[1]);
                     console.log(randomButton[2]);

                    document.getElementById(randomButton[0]).style.backgroundColor = "#FF9900";
                    document.getElementById(randomButton[1]).style.backgroundColor = "#FF9900";
                    document.getElementById(randomButton[2]).style.backgroundColor = "#FF9900";
                    
                    document.getElementById("audience").style.opacity = "0%"; 

                }
                )
                ;
                
                document.getElementById("phoneFriend").addEventListener("click", function(){
                
                    let randomButton = [];
                    let randomIndex = 0;
                    
                     while(randomButton.length <= 3)
                     {
                          randomIndex = Math.floor(Math.random()*4-0)+1;
                          
                      
                          if(randomButton.indexOf("ans" + randomIndex) === -1)
                          {
                              randomButton.push("ans" + randomIndex);
                          }
                     }
                    
                     console.log(randomButton[0]);
                     console.log(randomButton[1]);
                     console.log(randomButton[2]);

                    document.getElementById(randomButton[0]).style.backgroundColor = "#FF9900";
                    document.getElementById(randomButton[1]).style.backgroundColor = "#FF9900";
                    document.getElementById(randomButton[2]).style.backgroundColor = "#FF9900";

                    document.getElementById("phoneFriend").style.opacity = "0%"; 

                    
                }
                )
                ;
                
                
                
                
                console.log(currentPrize)

           
               
                }
                
                function showScore(linkTarget) {
            
                let propertyWidth = 1000;
                
                let propertyHeight = 750;
                
                let winLeft = (screen.width - propertyWidth) / 2;
                
                let winTop = (screen.height - propertyHeight) / 2;
                
                let winOptions = "toolbar=,menubar=no,location=no,scrollbars=yes,resizable=no";
                
                winOptions += ",width=" + propertyWidth;
                
                winOptions += ",height=" + propertyHeight;
                
                winOptions += ",left=" + winLeft;
                
                winOptions += ",top=" + winTop;
                
                scoreWindow = window.open(linkTarget, "score", winOptions);
                
                scoreWindow.focus();
                
                }
        
        gameLoop();
