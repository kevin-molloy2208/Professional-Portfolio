// JavaScript Document
document.getElementById("nameButton").addEventListener("click", function(){
        
        
                
        let playerName = document.getElementById("playerName").value;
        if(playerName == null){playeName="No Name Entered"}
        localStorage.setItem("playerName", playerName);
        window.open("gamePage.html")
        
        });