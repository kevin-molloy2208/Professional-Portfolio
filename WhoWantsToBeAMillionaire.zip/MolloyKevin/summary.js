// JavaScript Document
let playerName = localStorage.getItem("playerName");

             let result = localStorage.getItem("status");
             let questionStats = "";
             let roundNo = localStorage.getItem("round_no");
             let winnings = localStorage.getItem("score")
             
             let incorrectQuestion = localStorage.getItem("incorrect_question_q");
             let incorrectAnswers = localStorage.getItem("incorrect_q_answers_q");
             let incorrectCorrectAnswer = localStorage.getItem("incorrect_q_correct_answer_q");
             
             let incorrectStats = "The question you got wrong was:<br>" + incorrectQuestion + "<br>The possible answers were:<br>" + incorrectAnswers + "<br>The correct answer was:<br>" + incorrectCorrectAnswer;
             
             if(incorrectQuestion==null){incorrectStats = "You didnt get any question wrong. Good Job!"}
             
             if (result == "win"){result="You Win!"}
             if (result == "lose"){result = "You Lose!"}
             
             
             for(let i = 1; i<=roundNo; i++){
                let question = localStorage.getItem("question_" + i);
                let answers = localStorage.getItem("answers_q_" + i);
                let correct = localStorage.getItem("correct_answer_q_" + i);
                questionStats += "<br>Question " + i + "." + question  + "<br>Possible Answers:<br>" + answers + "<br>";
             }
             let roundCounter;
             if(roundNo==15){roundCounter="all"}
             else{roundCounter = roundNo-1;}
             
             
             document.getElementById("stats").innerHTML = (
             "<p>" + playerName + "! " + result + " You got " + roundCounter + " questions right! The answers will be displayed below <br>" + questionStats + "</p><br>" + 
             "<p>" + incorrectStats + "</p><br>" +
             "<p>You won " + winnings + "! Congratulations! Thanks for playing!</p>"
             ); 